# Import libraries
from pyrevit import script, revit

# Get UI doc and open views
uidoc = revit.uidoc
views_open = uidoc.GetOpenUIViews()

# Store Ids to string
view_ids = []

for v in views_open:
	id_string = v.ViewId.ToString()
	view_ids.append(id_string)

id_strings = ",".join(view_ids)

# Write data to pickle
script.store_data("ViewMemory", id_strings, this_project=True)