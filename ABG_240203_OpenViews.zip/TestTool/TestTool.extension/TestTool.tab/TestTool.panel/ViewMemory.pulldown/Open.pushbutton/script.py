# Import libraries
from pyrevit import script, forms, DB, revit

# Get doc and uidoc
doc   = revit.doc
uidoc = revit.uidoc

# Get pickled file
try:
	id_strings = script.load_data("ViewMemory", this_project=True)
except:
	id_strings == ""

# Catch if no views to open
if id_strings == "":
	forms.alert("No view memory available.", title = "Error")
	script.exit()

# Get the views from the model
id_strings = id_strings.split(",")

# Open the views we found
for i in id_strings:
	try:
		view_id = DB.ElementId(int(i))
		uidoc.ActiveView = doc.GetElement(view_id)
	except:
		pass